<?php $getLEDStatusFromNodeMCU='




0'; echo $getLEDStatusFromNodeMCU; ?>