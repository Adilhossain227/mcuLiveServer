-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 05, 2020 at 05:59 PM
-- Server version: 10.3.25-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adilhossain_iot`
--

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `temperature` float NOT NULL,
  `humidity` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `temperature`, `humidity`) VALUES
(1, 947, 188),
(2, 312, 972),
(3, 580, 447),
(4, 808, 576),
(5, 900, 595),
(6, 764, 174),
(7, 876, 469),
(8, 570, 996),
(9, 706, 283),
(10, 252, 746),
(11, 328, 148),
(12, 879, 817),
(13, 229, 230),
(14, 827, 117),
(15, 580, 86),
(16, 729, 94),
(17, 446, 379),
(18, 32, 503),
(19, 930, 164),
(20, 905, 956),
(21, 907, 951),
(22, 468, 65),
(23, 24, 245),
(24, 457, 19),
(25, 995, 60),
(26, 921, 944),
(27, 470, 666),
(28, 661, 73),
(29, 691, 20),
(30, 826, 645),
(31, 189, 646),
(32, 142, 807),
(33, 583, 712),
(34, 450, 505),
(35, 0, 792),
(36, 256, 352),
(37, 756, 537),
(38, 877, 476),
(39, 708, 276),
(40, 816, 143),
(41, 147, 546),
(42, 403, 426),
(43, 986, 601),
(44, 64, 819),
(45, 220, 93),
(46, 734, 679),
(47, 240, 201),
(48, 637, 70),
(49, 336, 386),
(50, 11, 357),
(51, 946, 339),
(52, 140, 819),
(53, 592, 231),
(54, 376, 712),
(55, 24, 707),
(56, 670, 172),
(57, 897, 5),
(58, 509, 89),
(59, 753, 379),
(60, 804, 632),
(61, 43, 899),
(62, 840, 752),
(63, 272, 376),
(64, 549, 604),
(65, 574, 706),
(66, 649, 368),
(67, 403, 700),
(68, 448, 105),
(69, 729, 41),
(70, 907, 235),
(71, 471, 57),
(72, 443, 243),
(73, 912, 869),
(74, 465, 66),
(75, 532, 968),
(76, 35, 255),
(77, 345, 633),
(78, 909, 557),
(79, 958, 770),
(80, 456, 313),
(81, 11, 542),
(82, 101, 459),
(83, 492, 459);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
