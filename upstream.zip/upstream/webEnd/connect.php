<?php

$dbname = 'db_name';
$dbuser = 'db_User';  
$dbpass = 'db_Pass'; 
$dbhost = 'localhost'; 

$connect = @mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

if(!$connect){
	echo "Error: " . mysqli_connect_error();
	exit();
}

echo "Connection Success!";

$temperature = $_GET["temperature"];
$humidity = $_GET["humidity"];



$query = "INSERT INTO project (temperature,humidity) VALUES ('$temperature','$humidity')";
$result = mysqli_query($connect,$query);

echo "Insertion Success!";

?>