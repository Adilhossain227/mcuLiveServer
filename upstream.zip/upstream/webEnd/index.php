<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Live Node MCU server">
	<meta name="author" content="Adil Hossain">
	<title>Tables | Live Node MCU Server</title>

	<link href="css/app.css" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="#">
          <span class="align-middle">Live Remote Node MCU Server</span>
        </a>


					<li class="sidebar-item active">
						<a class="sidebar-link" href="tables-bootstrap.html">
              <i class="align-middle" data-feather="list"></i> <span class="align-middle">Tables</span>
            </a>
					</li>

					

				

				
				</ul>

			
			</div>
		</nav>

		<div class="main">
		

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Data Table</h1>

					<div class="row">

						<div class="col-12 col-xl-6">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Live update from remote NODE MCU</h5>
									<h6 class="card-subtitle text-muted">Currently running live to server.</h6>
								</div>
								<table class="table">
									<thead>
										<tr>
											<th style="width:40%;">ID</th>
											<th style="width:25%">Temparature</th>
											<th class="d-none d-md-table-cell" style="width:25%">Humidity</th>
										
										</tr>
									</thead>
									
									<tbody>
									    <?php 
									    header("Refresh: 10");
					$dbname = 'db_name';
                    $dbuser = 'db_User';  
                    $dbpass = 'db_pass'; 
                    $dbhost = 'localhost'; 
                    $con = mysqli_connect($dbhost,$dbuser,$dbpass);
              	    mysqli_select_db($con,$dbname);
                    $query="SELECT * FROM project ORDER BY id DESC";
              		$query_result =mysqli_query($con,$query);
                    while($row= mysqli_fetch_array($query_result)) {
                    ?>
										<tr class="table-primary">
											<td><?php echo  $row["id"];?></td>
											<td><?php echo  $row["temperature"];?></td>
											<td class="d-none d-md-table-cell"><?php echo  $row["humidity"];?></td>
										
										</tr>
									<?php }?>
									</tbody>
								</table>
							</div>
						</div>
						<!--
						 rest of the designs
							<tr class="table-primary">
											<td>William Harris</td>
											<td>914-939-2458</td>
											<td class="d-none d-md-table-cell">May 15, 1948</td>
										
										</tr>
										<tr>
											<td>Sharon Lessman</td>
											<td>704-993-5435</td>
											<td class="d-none d-md-table-cell">Sep 14, 1965</td>
											
										</tr>
										<tr class="table-success">
											<td>Christina Mason</td>
											<td>765-382-8195</td>
											<td class="d-none d-md-table-cell">April 2, 1971</td>
											
										</tr>
										<tr class="table-warning" >
											<td>Robin Schneiders</td>
											<td>202-672-1407</td>
											<td class="d-none d-md-table-cell">October 12, 1966</td>
										
										</tr>
						-->
						<!--
						<div class="col-12 col-xl-6">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Condensed Table</h5>
									<h6 class="card-subtitle text-muted">Add <code>.table-sm</code> to make tables more compact by cutting cell padding in half.</h6>
								</div>
								<table class="table table-striped table-sm">
									<thead>
										<tr>
											<th>Operation System</th>
											<th class="text-right">Users</th>
											<th class="text-right">Share</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Windows</td>
											<td class="text-right">8.232</td>
											<td class="text-right">40%</td>
										</tr>
										<tr>
											<td>Mac OS</td>
											<td class="text-right">3.322</td>
											<td class="text-right">20%</td>
										</tr>
										<tr>
											<td>Linux</td>
											<td class="text-right">4.232</td>
											<td class="text-right">34%</td>
										</tr>
										<tr>
											<td>FreeBSD</td>
											<td class="text-right">1.121</td>
											<td class="text-right">12%</td>
										</tr>
										<tr>
											<td>Chrome OS</td>
											<td class="text-right">1.331</td>
											<td class="text-right">15%</td>
										</tr>
										<tr>
											<td>Android</td>
											<td class="text-right">2.301</td>
											<td class="text-right">20%</td>
										</tr>
										<tr>
											<td>iOS</td>
											<td class="text-right">1.162</td>
											<td class="text-right">14%</td>
										</tr>
										<tr>
											<td>Windows Phone</td>
											<td class="text-right">562</td>
											<td class="text-right">7%</td>
										</tr>
										<tr>
											<td>Other</td>
											<td class="text-right">1.181</td>
											<td class="text-right">14%</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>-->
					

<!--
						<div class="col-12">
							<div class="card">
								<div class="card-header">
									<h5 class="card-title">Always responsive</h5>
									<h6 class="card-subtitle text-muted">Across every breakpoint, use <code>.table-responsive</code> for horizontally scrolling tables.</h6>
								</div>
								<div class="table-responsive">
									<table class="table mb-0">
										<thead>
											<tr>
												<th scope="col">#</th>
												<th scope="col">Heading</th>
												<th scope="col">Heading</th>
												<th scope="col">Heading</th>
												<th scope="col">Heading</th>
												<th scope="col">Heading</th>
												<th scope="col">Heading</th>
												<th scope="col">Heading</th>
												<th scope="col">Heading</th>
												<th scope="col">Heading</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<th scope="row">1</th>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
											</tr>
											<tr>
												<th scope="row">2</th>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
											</tr>
											<tr>
												<th scope="row">3</th>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
												<td>Cell</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>-->
					</div>

				</div>
			</main>

			<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-left">
							<p class="mb-0">
								<a href="index.html" class="text-muted"><strong>Adil Hossain</strong></a> &copy; 2020
							</p>
						</div>
						
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="js/vendor.js"></script>
	<script src="js/app.js"></script>

</body>

</html>